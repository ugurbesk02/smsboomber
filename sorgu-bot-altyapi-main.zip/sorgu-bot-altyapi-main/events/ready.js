module.exports = {
    name: 'ready',
    execute(client) {
        console.log(`${client.user.tag} Hazırlandı BOT SAHIBI Retnox#2728`)

            client.user.setActivity(`Roblox`)
    }
}